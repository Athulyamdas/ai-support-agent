"""
app/agent/llm_factory.py — Build the correct LangChain LLM from config.

Keeping LLM construction in one place means you can swap providers
(OpenAI ↔ Anthropic) via a single env var.
"""

from langchain_core.language_models import BaseChatModel
import config
from app.utils.logger import get_logger

logger = get_logger(__name__)


def build_llm() -> BaseChatModel:
    """
    Return a configured LangChain chat model.

    Reads LLM_PROVIDER, LLM_MODEL, LLM_TEMPERATURE, LLM_MAX_TOKENS from config.
    Raises ValueError for unknown providers.
    """
    provider = config.LLM_PROVIDER
    logger.info(f"Building LLM: provider={provider}, model={config.LLM_MODEL}")

    if provider == "openai":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(
            model=config.LLM_MODEL,
            temperature=config.LLM_TEMPERATURE,
            max_tokens=config.LLM_MAX_TOKENS,
            openai_api_key=config.OPENAI_API_KEY,
        )

    if provider == "anthropic":
        from langchain_anthropic import ChatAnthropic
        return ChatAnthropic(
            model=config.LLM_MODEL,
            temperature=config.LLM_TEMPERATURE,
            max_tokens=config.LLM_MAX_TOKENS,
            anthropic_api_key=config.ANTHROPIC_API_KEY,
        )

    raise ValueError(
        f"Unknown LLM_PROVIDER '{provider}'. "
        "Supported values: 'openai', 'anthropic'."
    )
